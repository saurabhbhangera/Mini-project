export const environment = {
    production: false,
    weatherApiKey: 'c959cbb3b3f04183bfe61737250803'
  };
  